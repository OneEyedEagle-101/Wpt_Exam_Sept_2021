const mysql = require("mysql");
const Promise = require("bluebird");
Promise.promisifyAll(require("mysql/lib/Connection").prototype);

const dbdetail = {
    host:"localhost",
    user:"root",
    password:"cdac",
    database:"node"
};

const selectAllUser= async ()=>{
    
    const connection = mysql.createConnection(dbdetail);
    await connection.connectAsync();
    const sql ="SELECT * FROM MESSAGES";
    const list = await connection.queryAsync(sql);
    await connection.endAsync();
    console.log("Connection Established!!");
    return list;
};

const addUser= async (obj)=>{  
    const connection = mysql.createConnection(dbdetail);
    await connection.connectAsync();
    const sql =`INSERT INTO MESSAGES(message) values(?)`;
    const list = await connection.queryAsync(sql,[obj.message]);
    await connection.endAsync();
    console.log("Message Updated!!");
};

//selectAllUser();
//addUser({message: "Hello Test"});

module.exports = {selectAllUser,addUser};